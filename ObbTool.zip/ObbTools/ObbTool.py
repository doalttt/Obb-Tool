import os
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, Menu
from zipfile import ZipFile

KEYSTORE = "obb.keystore"
ALIAS = "obbtool"
PASSWORD = "OBBTool"


def find7zipcusitsgaylololol(search_root):
    for root, _, files in os.walk(search_root):
        for file in files:
            if file.lower() == "7z.exe":
                return os.path.join(root, file)
    return None


def unpackerrrr(obb_path, out_dir, progresscallingthing=None):
    os.makedirs(out_dir, exist_ok=True)

    serch = os.getcwd()
    sevenzippathhh = find7zipcusitsgaylololol(serch)
    if not sevenzippathhh:
        raise FileNotFoundError("kys")

    if progresscallingthing:
        progresscallingthing(10, "Starting unpacking...")

    cmd = [sevenzippathhh, 'x', obb_path, f'-o{out_dir}', '-y']
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    for line in proc.stdout:
        if progresscallingthing:
            progresscallingthing(50, "Unpacking...")

    proc.wait()
    if proc.returncode != 0:
        stderr = proc.stderr.read()
        raise RuntimeError(f"[ERROR], smth fugged up:\n{stderr}")

    if progresscallingthing:
        progresscallingthing(100, "[SUCCESS], unpacked folder")


def holyfuckthismakesmewannadie(folder, output_path, progresscallingthing=None):
    files = []
    for root, _, namethings in os.walk(folder):
        for f in namethings:
            files.append(os.path.join(root, f))

    howmuchfilesinhereee = len(files)
    with ZipFile(output_path, 'w') as archive:
        for i, file_path in enumerate(files):
            arcname = os.path.relpath(file_path, folder)
            archive.write(file_path, arcname)
            if progresscallingthing:
                progress = int((i + 1) / howmuchfilesinhereee * 100)
                progresscallingthing(progress, f"Packing file {i + 1} / {howmuchfilesinhereee}")


def signthebloodything(obb_path):
    java_root = r"C:\\Program Files\\Java"
    jarsigner_path = None

    for root, _, files in os.walk(java_root):
        for file in files:
            if file.lower() == "jarsigner.exe":
                jarsigner_path = os.path.join(root, file)
                break
        if jarsigner_path:
            break

    if not jarsigner_path:
        raise FileNotFoundError("[ERROR] jarsigner.exe not found in Java folder!")

    if not os.path.exists(KEYSTORE):
        raise RuntimeError("[ERROR] keystore not found!")

    cmd = [
        jarsigner_path,
        "-keystore", KEYSTORE,
        "-storepass", PASSWORD,
        "-keypass", PASSWORD,
        obb_path,
        ALIAS
    ]
    subprocess.run(cmd, check=True)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OBB Tool")
        self.geometry("420x270")
        self.resizable(False, False)

        self.folder_path = ""

        menubar = Menu(self)
        file_menu = Menu(menubar, tearoff=0)
        file_menu.add_command(label="Load Folder", command=self.loaddafolda)
        file_menu.add_command(label="Reset Progress", command=self.resettheprogressbarlol)
        file_menu.add_command(label="Custom Keystore", command=self.choose_custom_keystore)
        menubar.add_cascade(label="File", menu=file_menu)
        self.config(menu=menubar)

        self.label = tk.Label(self, text="Click here to select an OBB file", relief="groove")
        self.label.pack(fill="both", expand=True, padx=10, pady=(15, 5))
        self.label.bind("<Button-1>", self.obbselector)

        self.progress_var = tk.IntVar()
        self.progressbar = tk.ttk.Progressbar(self, variable=self.progress_var, maximum=100)
        self.progressbar.pack(fill="x", padx=20, pady=5)

        self.status_label = tk.Label(self, text="Idle")
        self.status_label.pack(pady=5)

        self.btn = tk.Button(self, text="Repack and Sign", command=self.repackthethingoooo, height=2, width=20)
        self.btn.pack(pady=(10, 15))

    def pissbar(self, percent, status):
        self.progress_var.set(percent)
        self.status_label.config(text=status)
        self.update_idletasks()

    def resettheprogressbarlol(self):
        self.pissbar(0, "Progress reset.")

    def choose_custom_keystore(self):
        global KEYSTORE
        global ALIAS
        global PASSWORD

        file_path = filedialog.askopenfilename(filetypes=[("Keystore files", "*.keystore")])
        if file_path:
            KEYSTORE = file_path
            ALIAS = simpledialog.askstring("Alias", "Enter key alias:", initialvalue=ALIAS) or ALIAS
            PASSWORD = simpledialog.askstring("Password", "Enter password:", show='*', initialvalue=PASSWORD) or PASSWORD
            messagebox.showinfo("Custom Keystore", f"Using: {KEYSTORE}\nAlias: {ALIAS}")

    def obbselector(self, event=None):
        path = filedialog.askopenfilename(filetypes=[("OBB files", "*.obb")])
        if path:
            out_dir = os.path.splitext(path)[0] + "_unpacked"

            def task():
                try:
                    self.pissbar(0, "Starting unpack...")
                    unpackerrrr(path, out_dir, self.pissbar)
                    self.pissbar(100, "Finished unpacking!")
                    messagebox.showinfo("[SUCCESS]", f"Unpacked to: {out_dir}")
                except Exception as e:
                    messagebox.showerror("Error", str(e))
                    self.pissbar(0, "")

            threading.Thread(target=task, daemon=True).start()

    def loaddafolda(self):
        folder = filedialog.askdirectory()
        if folder:
            self.folder_path = folder
            messagebox.showinfo("Folder Loaded", folder)

    def repackthethingoooo(self):
        if not self.folder_path:
            messagebox.showwarning("[ERROR]", "Load a folder first.")
            return

        def task():
            try:
                self.pissbar(0, "Starting pack...")
                repacked = "repacked.obb"
                holyfuckthismakesmewannadie(self.folder_path, repacked, self.pissbar)
                self.pissbar(90, "Signing...")
                signthebloodything(repacked)
                self.pissbar(100, "Finished exporting the obb file!")
                messagebox.showinfo("[SUCCESS]", f"Signed the obb {repacked}")
            except Exception as e:
                messagebox.showerror("Error", str(e))
                self.pissbar(0, "")

        threading.Thread(target=task, daemon=True).start()


if __name__ == "__main__":
    import tkinter.ttk
    import tkinter.simpledialog as simpledialog
    app = App()
    app.mainloop()
