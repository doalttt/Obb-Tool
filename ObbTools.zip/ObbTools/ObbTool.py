import os
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, Menu, scrolledtext
from zipfile import ZipFile

KEYSTORE = "obb.keystore"
ALIAS = "obbtool"
PASSWORD = "OBBTool"


def find7zipcusitsgaylololol(searchingthing):
    for root, _, files in os.walk(searchingthing):
        for file in files:
            if file.lower() == "7z.exe":
                return os.path.join(root, file)
    return None


def unpackerrrr(obbpath, outdir, progresscallingthing=None, logthing=None):
    os.makedirs(outdir, exist_ok=True)
    serch = os.getcwd()
    sevenzippathhh = find7zipcusitsgaylololol(serch)
    if not sevenzippathhh:
        raise FileNotFoundError("kys")

    if progresscallingthing:
        progresscallingthing(10, "Starting unpacking...")

    cmd = [sevenzippathhh, 'x', obbpath, f'-o{outdir}', '-y']
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    for line in proc.stdout:
        if logthing:
            logthing.insert(tk.END, line)
        if progresscallingthing:
            progresscallingthing(50, "Unpacking...")

    proc.wait()
    if proc.returncode != 0:
        stderr = proc.stderr.read()
        raise RuntimeError(f"[ERROR], smth fugged up:\n{stderr}")

    if progresscallingthing:
        progresscallingthing(100, "[SUCCESS], unpacked folder")


def holyfuckthismakesmewannadie(folder, outpuout, progresscallingthing=None, logthing=None):
    files = []
    for root, _, namethings in os.walk(folder):
        for f in namethings:
            files.append(os.path.join(root, f))

    howmuchfilesinhereee = len(files)
    with ZipFile(outpuout, 'w') as archive:
        for i, filepath in enumerate(files):
            arcname = os.path.relpath(filepath, folder)
            archive.write(filepath, arcname)
            if logthing:
                logthing.insert(tk.END, f"Packing: {arcname}\n")
            if progresscallingthing:
                progress = int((i + 1) / howmuchfilesinhereee * 100)
                progresscallingthing(progress, f"Packing file {i + 1} / {howmuchfilesinhereee}")


def signthebloodything(obb_path):
    if not os.path.exists(KEYSTORE):
        raise RuntimeError("[ERROR] obb.keystore not found in the folder!")
    
    javas_root = r"C:\Program Files\Java"
    jarsigner_path = None

    for root, _, files in os.walk(javas_root):
        for file in files:
            if file.lower() == "jarsigner.exe":
                jarsigner_path = os.path.join(root, file)
                break
        if jarsigner_path:
            break

    if not jarsigner_path or "jdk-11" not in jarsigner_path:
        jarsigner_path = r"C:\Program Files\Java\jdk-11\bin\jarsigner.exe"

    if not os.path.exists(jarsigner_path):
        raise FileNotFoundError("[ERROR] jarsigner.exe not found in Java folder or fallback path.")

    cmd = [
        jarsigner_path,
        "-keystore", KEYSTORE,
        "-storepass", PASSWORD,
        "-keypass", PASSWORD,
        obb_path,
        ALIAS
    ]
    try:
        subprocess.run(cmd, check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"[ERROR] faied to sign:\n{e}")



class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OBB Tool")
        self.geometry("600x400")
        self.resizable(False, False)

        self.folder_path = ""
        self.obbpath = ""

        menubar = Menu(self)
        file_menu = Menu(menubar, tearoff=0)
        file_menu.add_command(label="Load Folder", command=self.loaddafolda)
        file_menu.add_command(label="Load OBB", command=self.obbselector)
        file_menu.add_command(label="Reset Progress", command=self.resettheprogressbarlol)
        file_menu.add_command(label="Custom Keystore", command=self.choose_custom_keystore)
        menubar.add_cascade(label="File", menu=file_menu)
        self.config(menu=menubar)

        self.progress_var = tk.IntVar()
        self.progressbar = tk.ttk.Progressbar(self, variable=self.progress_var, maximum=100)
        self.progressbar.pack(fill="x", padx=20, pady=(10, 5))

        self.status_label = tk.Label(self, text="Idle")
        self.status_label.pack(pady=5)

        self.log = scrolledtext.ScrolledText(self, height=15)
        self.log.pack(fill="both", expand=True, padx=10, pady=(5, 10))

        buttonframe = tk.Frame(self)
        buttonframe.pack(pady=(0, 10))

        self.unpackbtn = tk.Button(buttonframe, text="Unpack OBB", command=self.UnpackButton, width=20)
        self.unpackbtn.pack(side=tk.LEFT, padx=10)

        self.btn = tk.Button(buttonframe, text="Repack and Sign", command=self.repackthethingoooo, width=20)
        self.btn.pack(side=tk.LEFT, padx=10)


    def pissbar(self, percent, status):
        self.progress_var.set(percent)
        self.status_label.config(text=status)
        self.update_idletasks()

    def resettheprogressbarlol(self):
        self.pissbar(0, "Progress reset.")
        self.log.delete("1.0", tk.END)

    def choose_custom_keystore(self):
        global KEYSTORE, ALIAS, PASSWORD
        filepath = filedialog.askopenfilename(filetypes=[("Keystore files", "*.keystore")])
        if filepath:
            KEYSTORE = filepath
            ALIAS = simpledialog.askstring("Alias", "Enter key alias:", initialvalue=ALIAS) or ALIAS
            PASSWORD = simpledialog.askstring("Password", "Enter password:", show='*', initialvalue=PASSWORD) or PASSWORD
            messagebox.showinfo("Custom Keystore", f"Using: {KEYSTORE}\nAlias: {ALIAS}")

    def obbselector(self):
        path = filedialog.askopenfilename(filetypes=[("OBB files", "*.obb")])
        if path:
            self.obbpath = path
            messagebox.showinfo("OBB Loaded", path)

    def UnpackButton(self):
        if not self.obbpath:
            messagebox.showwarning("[ERROR]", "No OBB selected.")
            return

        outdir = os.path.splitext(self.obbpath)[0] + "_unpacked"

        def task():
            try:
                self.pissbar(0, "Starting unpack...")
                unpackerrrr(self.obbpath, outdir, self.pissbar, self.log)
                self.pissbar(100, "Finished unpacking!")
                messagebox.showinfo("[SUCCESS]", f"Unpacked to: {outdir}")
            except Exception as e:
                messagebox.showerror("[ERROR]", str(e))
                self.pissbar(0, "")

        threading.Thread(target=task, daemon=True).start()

    def loaddafolda(self):
        folder = filedialog.askdirectory()
        if folder:
            self.folder_path = folder
            messagebox.showinfo("Folder Loaded", folder)

    def repackthethingoooo(self):
        if not self.folder_path:
            messagebox.showwarning("[ERROR]", "Load a folder first.")
            return

        def task():
            try:
                self.pissbar(0, "Starting pack...")
                repacked = "repacked.obb"
                holyfuckthismakesmewannadie(self.folder_path, repacked, self.pissbar, self.log)
                self.pissbar(90, "Signing...")
                signthebloodything(repacked)
                self.pissbar(100, "Finished exporting the obb file!")
                messagebox.showinfo("[SUCCESS]", f"Signed the obb {repacked}")
            except Exception as e:
                messagebox.showerror("[ERROR]", str(e))
                self.pissbar(0, "")

        threading.Thread(target=task, daemon=True).start()


if __name__ == "__main__":
    import tkinter.ttk
    import tkinter.simpledialog as simpledialog
    app = App()
    app.mainloop()